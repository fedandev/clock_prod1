<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAutorizacionsTable extends Migration 
{
	public function up()
	{
		Schema::create('autorizacions', function(Blueprint $table) {
            $table->increments('id');
            $table->integer('autorizacion_entrada');
            $table->integer('autorizacion_salida');
            $table->string('autorizacion_autorizado');
            $table->timestamps();
        });
	}

	public function down()
	{
		Schema::drop('autorizacions');
	}
}
