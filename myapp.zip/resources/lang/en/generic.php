<?php

return [

    
    'edit' => 'Edit',
    'index' => 'Home',
    'create' => 'Create',
    'show' => 'Show',
    'download' => 'Download',
    'Excel' => 'Cargar Excel',
];