<?php

namespace App\Observers;

use App\Models\Permiso;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class PermisoObserver
{
    public function creating(Permiso $permiso)
    {
        //
    }

    public function updating(Permiso $permiso)
    {
        //
    }
}