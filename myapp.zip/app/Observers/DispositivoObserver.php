<?php

namespace App\Observers;

use App\Models\Dispositivo;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class DispositivoObserver
{
    public function creating(Dispositivo $dispositivo)
    {
        //
    }

    public function updating(Dispositivo $dispositivo)
    {
        //
    }
}