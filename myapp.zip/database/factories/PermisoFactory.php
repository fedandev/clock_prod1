<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Permiso::class, function (Faker $faker) {
    return [
        // 'name' => $faker->name,
    ];
});
