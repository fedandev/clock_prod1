<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class Dispositivo extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['dispositivo_nombre', 'dispositivo_serial', 'dispositivo_modelo', 'dispositivo_ip', 'dispositivo_puerto', 'dispositivo_usuario', 'dispositivo_password', 'fk_empresa_id'];
    public $timestamps = false;
    
    public function Empresa(){
        return $this->hasOne('App\Models\Empresa','id','fk_empresa_id');
    }
    
    public function Registros(){
        return $this->hasMany('App\Models\Registro','id','fk_dispositivo_id');
    }
}
