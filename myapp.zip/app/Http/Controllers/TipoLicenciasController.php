<?php

namespace App\Http\Controllers;

use App\Models\TipoLicencia;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\TipoLicenciaRequest;

class TipoLicenciasController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', TipoLicencia::class);
		$tipo_licencias = TipoLicencia::get();
		return view('tipo_licencias.index', compact('tipo_licencias'));
	}

    public function show(TipoLicencia $tipo_licencia)
    {
    	$this->authorize('show', $tipo_licencia);
        return view('tipo_licencias.show', compact('tipo_licencia'));
    }

	public function create(TipoLicencia $tipo_licencia)
	{
		$this->authorize('create', $tipo_licencia);
		return view('tipo_licencias.create_and_edit', compact('tipo_licencia'));
	}

	public function store(TipoLicenciaRequest $request)
	{
		$this->authorize('store', TipoLicencia::class);	
		$tipo_licencia = TipoLicencia::create($request->all());
		return redirect()->route('tipo_licencias.show', $tipo_licencia->id)->with('message', 'Created successfully.');
	}

	public function edit(TipoLicencia $tipo_licencia)
	{
        $this->authorize('edit', $tipo_licencia);
		return view('tipo_licencias.create_and_edit', compact('tipo_licencia'));
	}

	public function update(TipoLicenciaRequest $request, TipoLicencia $tipo_licencia)
	{
		$this->authorize('update', $tipo_licencia);
		$tipo_licencia->update($request->all());

		return redirect()->route('tipo_licencias.show', $tipo_licencia->id)->with('message', 'Updated successfully.');
	}

	public function destroy(TipoLicencia $tipo_licencia)
	{
		$this->authorize('destroy', $tipo_licencia);
		$tipo_licencia->delete();

		return redirect()->route('tipo_licencias.index')->with('message', 'Deleted successfully.');
	}
}