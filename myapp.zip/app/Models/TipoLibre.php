<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class TipoLibre extends Model implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    public $timestamps = false;
    protected $fillable = ['nombre', 'descripcion'];

}
