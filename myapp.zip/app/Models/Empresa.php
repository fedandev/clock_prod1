<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class Empresa extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['empresa_nombre', 'empresa_telefono', 'empresa_estado', 'empresa_ingreso'];
    public $timestamps = false;
    
    public function Dispositivos(){
        return $this->hasMany('App\Models\Dispositivo','id','fk_empresa_id');
    }
    
}
