<?php

namespace App\Observers;

use App\Models\Licencia;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class LicenciaObserver
{
    public function creating(Licencia $Licencia)
    {
        //
    }

    public function updating(Licencia $Licencia)
    {
        //
    }
}