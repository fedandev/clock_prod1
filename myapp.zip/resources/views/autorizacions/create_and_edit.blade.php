@extends('layouts.app')

@section('content')

<div class="container">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
            
            <div class="panel-heading">
                <h1>
                    <i class="glyphicon glyphicon-edit"></i> Autorizacion /
                    @if($autorizacion->id)
                        Edit #{{$autorizacion->id}}
                    @else
                        Create
                    @endif
                </h1>
            </div>

            @include('common.error')

            <div class="panel-body">
                @if($autorizacion->id)
                    <form action="{{ route('autorizacions.update', $autorizacion->id) }}" method="POST" accept-charset="UTF-8">
                        <input type="hidden" name="_method" value="PUT">
                @else
                    <form action="{{ route('autorizacions.store') }}" method="POST" accept-charset="UTF-8">
                @endif

                    <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    
                <div class="form-group">
                    <label for="autorizacion_entrada-field">Autorizacion_entrada</label>
                    <input class="form-control" type="text" name="autorizacion_entrada" id="autorizacion_entrada-field" value="{{ old('autorizacion_entrada', $autorizacion->autorizacion_entrada ) }}" />
                </div> 
                <div class="form-group">
                    <label for="autorizacion_salida-field">Autorizacion_salida</label>
                    <input class="form-control" type="text" name="autorizacion_salida" id="autorizacion_salida-field" value="{{ old('autorizacion_salida', $autorizacion->autorizacion_salida ) }}" />
                </div> 
                <div class="form-group">
                	<label for="autorizacion_autorizado-field">Autorizacion_autorizado</label>
                	<input class="form-control" type="text" name="autorizacion_autorizado" id="autorizacion_autorizado-field" value="{{ old('autorizacion_autorizado', $autorizacion->autorizacion_autorizado ) }}" />
                </div>

                    <div class="well well-sm">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <a class="btn btn-link pull-right" href="{{ route('autorizacions.index') }}"><i class="glyphicon glyphicon-backward"></i>  Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection