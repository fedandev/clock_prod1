<?php

namespace App\Observers;

use App\Models\LibreDetalle;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class LibreDetalleObserver
{
    public function creating(LibreDetalle $libre_detalle)
    {
        //
    }

    public function updating(LibreDetalle $libre_detalle)
    {
        //
    }
}