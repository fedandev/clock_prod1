<?php

namespace App\Observers;

use App\Models\LicenciaDetalle;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class LicenciaDetalleObserver
{
    public function creating(LicenciaDetalle $licencia_detalle)
    {
        //
    }

    public function updating(LicenciaDetalle $licencia_detalle)
    {
        //
    }
}