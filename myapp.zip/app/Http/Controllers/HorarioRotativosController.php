<?php

namespace App\Http\Controllers;

use App\Models\HorarioRotativo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\HorarioRotativoRequest;

class HorarioRotativosController extends Controller
{
	protected $diastrabajo;
	
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', HorarioRotativo::class);		
		$horario_rotativos = HorarioRotativo::get();
		return view('horario_rotativos.index', compact('horario_rotativos'));
	}

    public function show(HorarioRotativo $horario_rotativo)
    {
    	$this->authorize('show', $horario_rotativo);	
        return view('horario_rotativos.show', compact('horario_rotativo'));
    }

	public function create(HorarioRotativo $horario_rotativo)
	{
		$this->authorize('create', $horario_rotativo);	
		return view('horario_rotativos.create_and_edit', compact('horario_rotativo'));
	}

	public function store(HorarioRotativoRequest $request)
	{
		$this->authorize('store', HorarioRotativo::class);
		$this->diastrabajo = intval($request->input('horariorotativo_diastrabajo'));
		$this->validate($request, [
            'horariorotativo_nombre' => 'required|string|max:191',
            'horariorotativo_diacomienzo' => 'required|string|max:191',
            'horariorotativo_diastrabajo' => 'required|integer|max:31',
            'horariorotativo_diaslibres' => 
            	function($attribute, $value, $fail) {
            		$suma = $value + $this->diastrabajo;
		            if ( $suma > 31) {
		                return $fail('La suma entre Días de trabajo y Días libres no debe superar los 31 días.');
		            }
		        },
            'fk_horario_id' => 'required|integer',
        ]);
        
		$horario_rotativo = HorarioRotativo::create($request->all());
		return redirect()->route('horario_rotativos.show', $horario_rotativo->id)->with('message', 'Created successfully.');
	}

	public function edit(HorarioRotativo $horario_rotativo)
	{
        $this->authorize('edit', $horario_rotativo);
		return view('horario_rotativos.create_and_edit', compact('horario_rotativo'));
	}

	public function update(HorarioRotativoRequest $request, HorarioRotativo $horario_rotativo)
	{
		$this->authorize('update', $horario_rotativo);
		$this->diastrabajo = intval($horario_rotativo->horariorotativo_diastrabajo);
		$this->validate($request, [
            'horariorotativo_nombre' => 'required|string|max:191',
            'horariorotativo_diacomienzo' => 'required|string|max:191',
            'horariorotativo_diastrabajo' => 'required|integer|max:31',
            'horariorotativo_diaslibres' => 
            	function($attribute, $value, $fail) {
            		$suma = $value + $this->diastrabajo;
		            if ( $suma > 31) {
		                return $fail('La suma entre Días de trabajo y Días libres no debe superar los 31 días.');
		            }
		        },
            'fk_horario_id' => 'required|integer',
        ]);
        
		$horario_rotativo->update($request->all());
	
		return redirect()->route('horario_rotativos.show', $horario_rotativo->id)->with('message', 'Updated successfully.');
	}

	public function destroy(HorarioRotativo $horario_rotativo)
	{
		$this->authorize('destroy', $horario_rotativo);
		$horario_rotativo->delete();
		echo '<script> localStorage.setItem("alertaverde", "Registro eliminado correctamente"); </script>';
		return redirect()->route('horario_rotativos.index')->with('message', 'Deleted successfully.');
	}
}