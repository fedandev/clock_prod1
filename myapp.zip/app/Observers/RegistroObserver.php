<?php

namespace App\Observers;

use App\Models\Registro;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class RegistroObserver
{
    public function creating(Registro $registro)
    {
        //
    }

    public function updating(Registro $registro)
    {
        //
    }
}