<?php

namespace App\Observers;

use App\Models\Autorizacion;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class AutorizacionObserver
{
    public function creating(Autorizacion $autorizacion)
    {
        //
    }

    public function updating(Autorizacion $autorizacion)
    {
        //
    }
}