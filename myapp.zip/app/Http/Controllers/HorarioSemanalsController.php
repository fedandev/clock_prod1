<?php

namespace App\Http\Controllers;

use App\Models\HorarioSemanal;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\HorarioSemanalRequest;

class HorarioSemanalsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', HorarioSemanal::class);	
		$horario_semanals = HorarioSemanal::get();
		return view('horario_semanals.index', compact('horario_semanals'));
	}

    public function show(HorarioSemanal $horario_semanal)
    {
    	$this->authorize('show', $horario_semanal);	
        return view('horario_semanals.show', compact('horario_semanal'));
    }

	public function create(HorarioSemanal $horario_semanal)
	{
		$this->authorize('create', $horario_semanal);	
		return view('horario_semanals.create_and_edit', compact('horario_semanal'));
	}

	public function store(HorarioSemanalRequest $request)
	{
		$this->authorize('store', HorarioSemanal::class);	
		$this->validate($request, [
            'horariosemanal_nombre' => 'required|string|max:191',
            'horariosemanal_horas' => 'required',
        ]);
		$horario_semanal = HorarioSemanal::create($request->all());
		return redirect()->route('horario_semanals.show', $horario_semanal->id)->with('message', 'Created successfully.');
	}

	public function edit(HorarioSemanal $horario_semanal)
	{
	    $this->authorize('edit', $horario_semanal);
		return view('horario_semanals.create_and_edit', compact('horario_semanal'));
	}

	public function update(HorarioSemanalRequest $request, HorarioSemanal $horario_semanal)
	{
		$this->authorize('update', $horario_semanal);
		$this->validate($request, [
            'horariosemanal_nombre' => 'required|string|max:191',
            'horariosemanal_horas' => 'required',
        ]);
		$horario_semanal->update($request->all());

		return redirect()->route('horario_semanals.show', $horario_semanal->id)->with('message', 'Updated successfully.');
	}

	public function destroy(HorarioSemanal $horario_semanal)
	{
		//return $horario_semanal;	
		$this->authorize('destroy', $horario_semanal);
		$horario_semanal->delete();
		echo '<script> localStorage.setItem("alertaverde", "Registro eliminado correctamente"); </script>';
		return redirect()->route('horario_semanals.index')->with('message', 'Deleted successfully.');
	}
	
	public function delete($id)
	{
		$horario_semanal = HorarioSemanal::find($id) ;	
		$this->authorize('destroy', $horario_semanal);
		$horario_semanal->delete();
		echo '<script> localStorage.setItem("alertaverde", "Registro eliminado correctamente"); </script>';
		return redirect()->route('horario_semanals.index')->with('message', 'Deleted successfully.');
	}
}