<?php

namespace App\Observers;

use App\Models\Oficina;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class OficinaObserver
{
    public function creating(Oficina $oficina)
    {
        //
    }

    public function updating(Oficina $oficina)
    {
        //
    }
}