<?php

namespace App\Http\Controllers;

use App\Models\TipoLibre;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\TipoLibreRequest;

class TipoLibresController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }

	public function index()
	{
		$tipo_libres = TipoLibre::paginate();
		return view('tipo_libres.index', compact('tipo_libres'));
	}

    public function show(TipoLibre $tipo_libre)
    {
        return view('tipo_libres.show', compact('tipo_libre'));
    }

	public function create(TipoLibre $tipo_libre)
	{
		return view('tipo_libres.create_and_edit', compact('tipo_libre'));
	}

	public function store(TipoLibreRequest $request)
	{
		$tipo_libre = TipoLibre::create($request->all());
		return redirect()->route('tipo_libres.show', $tipo_libre->id)->with('message', 'Created successfully.');
	}

	public function edit(TipoLibre $tipo_libre)
	{
        $this->authorize('update', $tipo_libre);
		return view('tipo_libres.create_and_edit', compact('tipo_libre'));
	}

	public function update(TipoLibreRequest $request, TipoLibre $tipo_libre)
	{
		$this->authorize('update', $tipo_libre);
		$tipo_libre->update($request->all());

		return redirect()->route('tipo_libres.show', $tipo_libre->id)->with('message', 'Updated successfully.');
	}

	public function destroy(TipoLibre $tipo_libre)
	{
		$this->authorize('destroy', $tipo_libre);
		$tipo_libre->delete();

		return redirect()->route('tipo_libres.index')->with('message', 'Deleted successfully.');
	}
}