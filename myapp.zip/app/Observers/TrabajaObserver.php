<?php

namespace App\Observers;

use App\Models\Trabaja;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class TrabajaObserver
{
    public function creating(Trabaja $trabaja)
    {
        //
    }

    public function updating(Trabaja $trabaja)
    {
        //
    }
}