<?php

namespace App\Observers;

use App\Models\Sucursal;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class SucursalObserver
{
    public function creating(Sucursal $sucursal)
    {
        //
    }

    public function updating(Sucursal $sucursal)
    {
        //
    }
}