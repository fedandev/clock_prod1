<?php

namespace App\Http\Controllers;

use App\Models\Turno;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\TurnoRequest;

class TurnosController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', Turno::class);	
		$turnos = Turno::get();
		return view('turnos.index', compact('turnos'));
	}

    public function show(Turno $turno)
    {
    	$this->authorize('show', $turno);	
        return view('turnos.show', compact('turno'));
    }

	public function create(Turno $turno)
	{
		$this->authorize('create', $turno);
		return view('turnos.create_and_edit', compact('turno'));
	}

	public function store(TurnoRequest $request)
	{
		$this->authorize('store', Turno::class);
		$turno = Turno::create($request->all());
		return redirect()->route('turnos.show', $turno->id)->with('message', 'Created successfully.');
	}

	public function edit(Turno $turno)
	{
        $this->authorize('edit', $turno);
		return view('turnos.create_and_edit', compact('turno'));
	}

	public function update(TurnoRequest $request, Turno $turno)
	{
		$this->authorize('update', $turno);
		$turno->update($request->all());

		return redirect()->route('turnos.show', $turno->id)->with('message', 'Updated successfully.');
	}

	public function destroy(Turno $turno)
	{
		$this->authorize('destroy', $turno);
		$turno->delete();

		return redirect()->route('turnos.index')->with('message', 'Deleted successfully.');
	}
}