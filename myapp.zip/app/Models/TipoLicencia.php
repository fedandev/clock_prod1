<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class TipoLicencia extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['tipolicencia_nombre', 'tipolicencia_descripcion'];
    public $timestamps = false;
}
