<?php

namespace App\Observers;

use App\Models\Horario;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class HorarioObserver
{
    public function creating(Horario $horario)
    {
        //
    }

    public function updating(Horario $horario)
    {
        //
    }
}