<?php

namespace App\Observers;

use App\Models\Sesion;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class SesionObserver
{
    public function creating(Sesion $sesion)
    {
        //
    }

    public function updating(Sesion $sesion)
    {
        //
    }
}