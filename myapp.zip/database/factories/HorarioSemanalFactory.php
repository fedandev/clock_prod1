<?php

use Faker\Generator as Faker;

$factory->define(App\Models\HorarioSemanal::class, function (Faker $faker) {
    return [
        // 'name' => $faker->name,
    ];
});
