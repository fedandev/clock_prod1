<?php

namespace App\Observers;

use App\Models\HorarioRotativo;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class HorarioRotativoObserver
{
    public function creating(HorarioRotativo $horario_rotativo)
    {
        //
    }

    public function updating(HorarioRotativo $horario_rotativo)
    {
        //
    }
}