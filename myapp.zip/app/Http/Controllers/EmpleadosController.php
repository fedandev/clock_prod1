<?php

namespace App\Http\Controllers;

use App\Models\Empleado;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\EmpleadoRequest;

class EmpleadosController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', Empleado::class);	
		$empleados = Empleado::get();
		return view('empleados.index', compact('empleados'));
	}

    public function show(Empleado $empleado)
    {
    	$this->authorize('show', $empleado);		
        return view('empleados.show', compact('empleado'));
    }

	public function create(Empleado $empleado)
	{
		$this->authorize('create', $empleado);	
		return view('empleados.create_and_edit', compact('empleado'));
	}

	public function store(EmpleadoRequest $request)
	{
		$this->authorize('store', Empleado::class);
		$this->validate($request, [
            'empleado_cedula' => 'required|string|max:191',
            'empleado_nombre' => 'required|string|max:191',
            'fk_tipoempleado_id' => 'required|integer',
            'fk_oficina_id' => 'required|integer',
        ]);
		$empleado = Empleado::create($request->all());
		return redirect()->route('empleados.show', $empleado->id)->with('message', 'Created successfully.');
	}

	public function edit(Empleado $empleado)
	{
        $this->authorize('edit', $empleado);
		return view('empleados.create_and_edit', compact('empleado'));
	}

	public function update(EmpleadoRequest $request, Empleado $empleado)
	{
		$this->authorize('update', $empleado);
		$this->validate($request, [
            'empleado_cedula' => 'required|string|max:191',
            'empleado_nombre' => 'required|string|max:191',
            'fk_tipoempleado_id' => 'required|integer',
            'fk_oficina_id' => 'required|integer',
        ]);
		$empleado->update($request->all());
		return redirect()->route('empleados.show', $empleado->id)->with('message', 'Updated successfully.');
	}

	public function destroy(Empleado $empleado)
	{
		$this->authorize('destroy',$empleado);
		$empleado->delete();
		return redirect()->route('empleados.index')->with('message', 'Deleted successfully.');
	}
}