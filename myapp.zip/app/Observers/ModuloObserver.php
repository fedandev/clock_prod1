<?php

namespace App\Observers;

use App\Models\Modulo;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class ModuloObserver
{
    public function creating(Modulo $modulo)
    {
        //
    }

    public function updating(Modulo $modulo)
    {
        //
    }
}