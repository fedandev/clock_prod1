<?php

namespace App\Observers;

use App\Models\Empresa;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class EmpresaObserver
{
    public function creating(Empresa $empresa)
    {
        //
    }

    public function updating(Empresa $empresa)
    {
        //
    }
}