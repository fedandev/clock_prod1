<?php

namespace App\Observers;

use App\Models\TipoLicencia;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class TipoLicenciaObserver
{
    public function creating(TipoLicencia $tipo_licencium)
    {
        //
    }

    public function updating(TipoLicencia $tipo_licencium)
    {
        //
    }
}