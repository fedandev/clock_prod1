<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Vista ejemplo</title>
</head>
<body>
    <h1>Hola mundo desde Laravel</h1>
    <!--<form action="/ajuste" method="POST">
        {{ csrf_field() }}
        <input type="text" name="nombre"/>
        <input type="text" name="valor"/>
        <input type="text" name="descripcion"/>
        <input type="submit" value="Submit"/>
    </form>-->
</body>
</html>