<?php

namespace App\Observers;

use App\Models\Mensaje;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class MensajeObserver
{
    public function creating(Mensaje $mensaje)
    {
        //
    }

    public function updating(Mensaje $mensaje)
    {
        //
    }
}