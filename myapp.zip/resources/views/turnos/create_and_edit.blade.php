@extends('layouts.app')

@section('content')

    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>
                            <i class="fa fa-edit"></i> Turno /
                            @if($turno->id)
                                Editar #{{$turno->turno_nombre}}
                            @else
                                Nuevo
                            @endif
                        </h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                        </div>
                    </div>
                    
                    <div class="ibox-content">
                        @include('common.error')
                        @if($turno->id)
                            <form action="{{ route('turnos.update', $turno->id) }}" method="POST" accept-charset="UTF-8" class="form-horizontal">
                                <input type="hidden" name="_method" value="PUT">
                        @else
                            <form action="{{ route('turnos.store') }}" method="POST" accept-charset="UTF-8" class="form-horizontal">
                        @endif
        
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Nombre</label>
                                    <div class="col-sm-6"><input class="form-control" type="text" name="turno_nombre" id="turno_nombre-field" value="{{ old('turno_nombre', $turno->turno_nombre ) }}"></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Lunes</label>
                                    <div class="col-sm-3"><div class="i-checks"><label> <input type="checkbox" class="form-control" name="turno_lunes" id="turno_lunes-field" value="{{ old('turno_lunes', $turno->turno_lunes ) }}1"></label></div></div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Martes</label>
                                    <div class="col-sm-3"><div class="i-checks"><label> <input type="checkbox" class="form-control" name="turno_martes" id="turno_martes-field" value="{{ old('turno_martes', $turno->turno_martes ) }}1"></label></div></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Miercoles</label>
                                    <div class="col-sm-3"><div class="i-checks"><label> <input type="checkbox" class="form-control" name="turno_miercoles" id="turno_miercoles-field" value="{{ old('turno_miercoles', $turno->turno_miercoles ) }}1"></label></div></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Jueves</label>
                                    <div class="col-sm-3"><div class="i-checks"><label> <input type="checkbox" class="form-control" name="turno_jueves" id="turno_jueves-field" value="{{ old('turno_jueves', $turno->turno_jueves ) }}1"></label></div></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Viernes</label>
                                    <div class="col-sm-3"><div class="i-checks"><label> <input type="checkbox" class="form-control" name="turno_viernes" id="turno_viernes-field" value="{{ old('turno_viernes', $turno->turno_viernes ) }}1"></label></div></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Sabado</label>
                                    <div class="col-sm-3"><div class="i-checks"><label> <input type="checkbox" class="form-control" name="turno_sabado" id="turno_sabado-field" value="{{ old('turno_sabado', $turno->turno_sabado ) }}1"></label></div></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Domingo</label>
                                    <div class="col-sm-3"><div class="i-checks"><label> <input type="checkbox" class="form-control" name="turno_domingo" id="turno_domingo-field" value="{{ old('turno_domingo', $turno->turno_domingo ) }}1"></label></div></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Horario</label>
                                    <div class="col-sm-3">
                                        <select class="select2_demo_2 form-control" name="fk_horario_id" id="fk_horario_id-field" value="{{ old('fk_horario_id', $turno->fk_horario_id ) }}">
                                            @include('layouts.horarios')
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                 
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a class="btn btn-white" href="{{ route('turnos.index') }}"> Cancelar</a>
                                        <button class="btn btn-primary" type="submit">Guardar</button>
                                    </div>
                                </div>
                                
                            </form>
                    </div>    
                </div>
            </div>
        </div>
    </div>

            

@endsection

@section('scripts')

    <script>
        $(document).ready(function(){
            $(".select2_demo_2").select2();
        });
                  
    </script>
    
@endsection