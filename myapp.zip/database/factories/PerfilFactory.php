<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Perfil::class, function (Faker $faker) {
    return [
        // 'name' => $faker->name,
    ];
});
