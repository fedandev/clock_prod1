<?php

namespace App\Http\Controllers;

use App\Models\Sucursal;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\SucursalRequest;

class SucursalsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', Sucursal::class);
		$sucursals = Sucursal::get();
		return view('sucursals.index', compact('sucursals'));
	}

    public function show(Sucursal $sucursal)
    {
    	$this->authorize('show', $sucursal);	
        return view('sucursals.show', compact('sucursal'));
    }

	public function create(Sucursal $sucursal)
	{
		$this->authorize('create', $sucursal);
		return view('sucursals.create_and_edit', compact('sucursal'));
	}

	public function store(SucursalRequest $request)
	{
		$this->authorize('store', Sucursal::class);	
		$sucursal = Sucursal::create($request->all());
		return redirect()->route('sucursals.show', $sucursal->id)->with('message', 'Created successfully.');
	}

	public function edit(Sucursal $sucursal)
	{
        $this->authorize('edit', $sucursal);
		return view('sucursals.create_and_edit', compact('sucursal'));
	}

	public function update(SucursalRequest $request, Sucursal $sucursal)
	{
		$this->authorize('update', $sucursal);
		$sucursal->update($request->all());

		return redirect()->route('sucursals.show', $sucursal->id)->with('message', 'Updated successfully.');
	}

	public function destroy(Sucursal $sucursal)
	{
		$this->authorize('destroy', $sucursal);
		$sucursal->delete();

		return redirect()->route('sucursals.index')->with('message', 'Deleted successfully.');
	}
}