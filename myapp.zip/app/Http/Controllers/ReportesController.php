<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use App\Models\Empleado;
use App\Models\Registro;
use App\Models\Ajuste;
use DateTime;
use Barryvdh\DomPDF\Facade as PDF;
use Carbon\Carbon;
use Illuminate\Support\Facades\Gate;


class ReportesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index()	{
	    $controller = 'reportes';
		if (Gate::allows('view-report', $controller)) {
           return view('reportes.index');
        }else{
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
	}
    
    public function horasTrabajadasEmpleado(Request $request, Empleado $empleado){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
        
        $fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();
        $registros = DB::table('v_horas')->whereBetween('registro_fecha', array($fechainicio,$fechafin))->where('fk_empleado_cedula',$cedula)->orderBy('registro_fecha', 'asc')->get();
        
        
        
        $tiposRegistros = array(
            array("Nombre" => "Manual",
                  "Color" => "#62FF00",
            ),
            array("Nombre" => "Falta Justificada",
                  "Color" => "#FFB500",
            ),
            array("Nombre" => "Medica",
                  "Color" => "#00ACFF",
            ),
            array("Nombre" => "Licencia",
                  "Color" => "#00FFD1",
            ),
            array("Nombre" => "Fingerpint",
                  "Color" => "",
            ),
        );
        $pdf = PDF::loadView('pdf.horasTrabajadas', compact('registros','fechainicio','fechafin','empleado','tiposRegistros','suma'));
    	return $pdf->stream('listado.pdf');             //Ver PDF sin descargar
    	//return $pdf->download('listado.pdf');         //Forzar descarga de PDF
    }
    
    public function entradasYsalidas(Request $request){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
        
    	$fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();
    	$registros = Registro::whereBetween('registro_fecha', array($fechainicio,$fechafin))->where('fk_empleado_cedula',$cedula)->orderBy('registro_fecha', 'desc')->get();
        
    	
    	$pdf = PDF::loadView('pdf.entradasYsalidas', compact('registros','fechainicio','fechafin','empleado'));
    	
    	return $pdf->stream('listado.pdf');             //Ver PDF sin descargar
    	//return $pdf->download('listado.pdf');         //Forzar descarga de PDF
    }
    
    public function llegadasTarde(Request $request){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
        $fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();
        $tiempo = Ajuste::where('ajuste_nombre','leave_earn' )->first();
        $horario = null;
        
        $trabaja = $empleado[0]->trabaja()->whereBetween('trabaja_fechainicio', array($fechainicio,$fechafin))->whereBetween('trabaja_fechafin', array($fechainicio,$fechafin))->first();
        
        if ($trabaja){
            if(!is_null($trabaja->fk_horariorotativo_id)){
                $horario = $trabaja->horariorotativo->horario->horario_entrada;
            }elseif(!is_null($trabaja->fk_turno_id)){
                $horario = $trabaja->turno->horario->horario_entrada;
            }
        }else{
            return back()->with('warning', 'El empleado no tiene horario asociado para el rango de fechas.');
        }
        
        if(!is_null($horario)){
            $date = new DateTime('2018-05-07 '.$horario); // Por defecto la hora actual
            $dateTope = new DateTime('2018-05-07 '.$horario); // Por defecto la hora actual
            $dateTope = $dateTope->modify('+360 minutes');
            $date= $date->modify( $tiempo->ajuste_valor." ". $tiempo->ajuste_descripcion );
            $hora = $date->format('H:i:s');
            $horaTope = $dateTope->format('H:i:s');
            $registros = Registro::whereBetween('registro_fecha', array($fechainicio,$fechafin))->where('fk_empleado_cedula',$cedula)->whereTime('registro_hora', '>', $hora)->whereTime('registro_hora','<',$horaTope)->where('registro_tipo','I')->orderBy('registro_fecha', 'asc')->get();
            
            $pdf = PDF::loadView('pdf.llegadasTardes', compact('registros','fechainicio','fechafin','empleado','horario'));
    	
        	return $pdf->stream('listado.pdf');             //Ver PDF sin descargar
        	//return $pdf->download('listado.pdf');         //Forzar descarga de PDF
        }
    }
    
    public function salidasAntes(Request $request){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
        $fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();
        $tiempo = Ajuste::where('ajuste_nombre','leave_earn' )->first();
        $horario = null;
        
        $trabaja = $empleado[0]->trabaja()->whereBetween('trabaja_fechainicio', array($fechainicio,$fechafin))->whereBetween('trabaja_fechafin', array($fechainicio,$fechafin))->first();
        
        
        if ($trabaja){
            if(!is_null($trabaja->fk_horariorotativo_id)){
                $horario = $trabaja->horariorotativo->horario->horario_salida;
            }elseif(!is_null($trabaja->fk_turno_id)){
                $horario = $trabaja->turno->horario->horario_salida;
            }
        }else{
            return back()->with('warning', 'El empleado no tiene horario asociado para el rango de fechas.');
        }
       
        
        if(!is_null($horario)){
            $date = new DateTime('2018-05-07 '.$horario);       // Por defecto la hora actual
            $dateTope = new DateTime('2018-05-07 '.$horario);   // Por defecto la hora actual
            $dateTope = $dateTope->modify('+360 minutes');
            $date= $date->modify( $tiempo->ajuste_valor." ". $tiempo->ajuste_descripcion );
            $hora = $date->format('H:i:s');
            $horaTope = $dateTope->format('H:i:s');
            $registros = Registro::whereBetween('registro_fecha', array($fechainicio,$fechafin))->where('fk_empleado_cedula',$cedula)->whereTime('registro_hora', '<', $horario)->whereTime('registro_hora','<',$horaTope)->where('registro_tipo','O')->orderBy('registro_fecha', 'asc')->get();
            
            $pdf = PDF::loadView('pdf.salidasAntes', compact('registros','fechainicio','fechafin','empleado','horario'));
    	
        	return $pdf->stream('listado.pdf');             //Ver PDF sin descargar
        	//return $pdf->download('listado.pdf');         //Forzar descarga de PDF
        
            
        }
    }
    
    public function horasNocturnas(Request $request){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
        $fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();
        $inicioNoche = ajuste('nocturnal_start');
        $finNoche = ajuste('nocturnal_end');
        
        $registros = DB::select("SELECT * FROM  v_horas WHERE  fk_empleado_cedula =  :cedula AND  registro_fecha BETWEEN  :fechainicio AND  :fechafin AND TIME(registro_entrada) >=  :inicioNoche AND TIME(registro_salida) <= :finNoche ORDER BY registro_fecha ASC", ['cedula' => $cedula, 'fechainicio' => $fechainicio, 'fechafin' => $fechafin, 'inicioNoche' => $inicioNoche, 'finNoche' => $finNoche]);
        
        $registros = collect( $registros);
      
        foreach($registros as $registro){
            $entrada = new DateTime($registro->registro_entrada);
            $entrada = $entrada->format('H:i:s');
            $salida = new DateTime($registro->registro_salida);
            $salida = $salida->format('H:i:s');

            if($entrada < $inicioNoche && $entrada > $salida && $salida <= $finNoche){
                $nocturnidad = date('H:i:s', strtotime("00:00:00") + strtotime($salida) - strtotime($inicioNoche));
                $registro->registro_totalHoras = $nocturnidad;
            }elseif($entrada >= $inicioNoche && $entrada > $salida && $salida > $finNoche){
                $nocturnidad = date('H:i:s', strtotime("00:00:00") + strtotime($finNoche) - strtotime($entrada));
                $registro->registro_totalHoras = $nocturnidad;
            }elseif($entrada >= $inicioNoche && $entrada < $salida && $salida <= $finNoche){
                $nocturnidad = date('H:i:s', strtotime("00:00:00") + strtotime($salida) - strtotime($entrada));
                $registro->registro_totalHoras = $nocturnidad;
            }
        }
        
        $pdf = PDF::loadView('pdf.horasNocturnas', compact('registros','fechainicio','fechafin','empleado'));
    	
        return $pdf->stream('listado.pdf');             //Ver PDF sin descargar
    }
    
    public function listadoFaltas(Request $request){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
        $fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();
        $registros = DB::table('v_horas')->whereBetween('registro_fecha', array($fechainicio,$fechafin))->where('fk_empleado_cedula',$cedula)->orderBy('registro_fecha', 'asc')->get();
        
        
    }
    
    function Diasquetrabajarotativo($trabajoingresado,$libresingresado,$empezamos,$mes){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
    	$datos3 = explode("-",$mes);
    	$month=$datos3[1];
    	$year=$datos3[0];
    	$diaSemana=date("w",mktime(0,0,0,$month,1,$year))+7;	
    	$ultimoDiaMes=date("d",(mktime(0,0,0,$month+1,1,$year)-1));
    	$last_cell=$diaSemana+$ultimoDiaMes;
    	$x=0;
    	$diastrab = array();
    	$primerdia = 0;
    	$contador=0;
    	$contador2=0;
    	$dias = array('','Lunes','Martes','Miercoles','Jueves','Viernes','Sabado','Domingo');
    	for($i=1;$i<=44;$i++){
    		if($i==$diaSemana){
    			$day=1;
    		}
    		if($i<$diaSemana || $i>=$last_cell){
    		}else{
    			// mostramos el dia
    			if($day<10){
    				$day='0'.$day;
    			}
    			$numero = $day;
    			$numero .= "-";
    			$numero .= $month;
    			$numero .= "-";
    			$numero .= $year;
    			$agregar = $year;
    			$agregar .= "-";
    			$agregar .= $month;
    			$agregar .= "-";
    			$agregar .= $day;
    			$fecha = date('N', strtotime($numero));
    			$contador++;
    			if($contador<=$trabajoingresado){
    				if($primerdia==0){
    					if($fecha == $empezamos){
    						//echo '---'.$agregar.'---';
    						$diastrab[$x][0]=$agregar;
    						$x++;
    						$primerdia = 1;
    					}else{
    						$contador--;
    					}
    				}else{
    					$diastrab[$x][0]=$agregar;
    					$x++;
    				}
    			}else{
    				$contador2++;
    				if($contador2==$libresingresado){
    					$contador = 0;
    					$contador2=0;
    				}
    			}
    			$day++;
    		}
    		if($i%7==0){
    		}
    	}
    	return $diastrab;
    }
    
    function Diasquetrabaja($diacomienzo,$diafin,$id){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
    	$datos3 = explode("-",$diacomienzo);
    	$month=$datos3[1];
    	$year=$datos3[0];
    	$lunes="NO";$martes="NO";$miercoles="NO";$jueves="NO";$viernes="NO";$sabado="NO";$domingo="NO";
    	$datos3=Seleccionar("trabaja a1, turnos a2, horarios a3","*","a1.Turno_Id = a2.Turno_Id AND a2.Horario_Id = a3.Horario_Id AND a1.Trabaja_Id=".$id);
    	while($row3=mysqli_fetch_array($datos3)){
    		if($row3['Turno_Lunes']==1){
    			$lunes="SI";
    		}
    		if($row3['Turno_Martes']==1){
    			$martes="SI";
    		}
    		if($row3['Turno_Miercoles']==1){
    			$miercoles="SI";
    		}
    		if($row3['Turno_Jueves']==1){
    			$jueves="SI";
    		}
    		if($row3['Turno_Viernes']==1){
    			$viernes="SI";
    		}
    		if($row3['Turno_Sabado']==1){
    			$sabado="SI";
    		}
    		if($row3['Turno_Domingo']==1){
    			$domingo="SI";
    		}
    	}
    	$diaSemana=date("w",mktime(0,0,0,$month,1,$year))+7; 
    	$ultimoDiaMes=date("d",(mktime(0,0,0,$month+1,1,$year)-1));
    	$last_cell=$diaSemana+$ultimoDiaMes;
    	$x=0;
    	$diastrab = array();
    	for($i=1;$i<=42;$i++){
    		if($i==$diaSemana){
    			$day=1;
    		}
    		if($i<$diaSemana || $i>=$last_cell){
    		}else{
    			if($day<10){
    				$day='0'.$day;
    			}
    			$numero = $day;
    			$numero .= "-";
    			$numero .= $month;
    			$numero .= "-";
    			$numero .= $year;
    			$agregar = $year;
    			$agregar .= "-";
    			$agregar .= $month;
    			$agregar .= "-";
    			$agregar .= $day;
    			$fecha = date('N', strtotime($numero));
    			$entro="NO";
    			if($fecha==1 AND $lunes=="SI"){
    				$entro = "SI";
    			}
    			if($fecha==2 AND $martes=="SI"){
    				$entro = "SI";
    			}
    			if($fecha==3 AND $miercoles=="SI"){
    				$entro = "SI";
    			}
    			if($fecha==4 AND $jueves=="SI"){
    				$entro = "SI";
    			}
    			if($fecha==5 AND $viernes=="SI"){
    				$entro = "SI";
    			}
    			if($fecha==6 AND $sabado=="SI"){
    				$entro = "SI";
    			}
    			if($fecha==7 AND $domingo=="SI"){
    				$entro = "SI";
    			}
    			if($entro=="SI"){
    				if($agregar>=$diacomienzo AND $agregar<=$diafin){
    					if($agregar>=$_POST['fecha1'] AND $agregar<=$_POST['fecha2']){
    						$diastrab[$x][0]=$agregar;
    						$x++;
    					}
    				}
    			}
    			$day++;
    		}
    		if($i%7==0){
    		}
    	}
    	return $diastrab;
    }
    
    public function horasExtras(Request $request){
         $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }
        $fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();

        $registros = Registro::whereBetween('registro_fecha', array($fechainicio,$fechafin))->where('fk_empleado_cedula',$cedula)->where('registro_tipo','O')->orderBy('registro_fecha', 'asc')->get();
        
        $pdf = PDF::loadView('pdf.horasExtras', compact('registros','fechainicio','fechafin','empleado'));
	    return $pdf->stream('listado.pdf');             //Ver PDF sin descargar
    }
    
    public function libresConcedidos(Request $request){
        $controller = 'reportes';
		if (!Gate::allows('view-report', $controller)) {
           echo '<script> localStorage.setItem("alertaroja", "No esta autorizado a ejecutar la acción"); </script>'; 
           return redirect()->route('main'); 
        }    
           
        $fechainicio = $request->input('fechainicio');
        $fechafin = $request->input('fechafin');
        $cedula = $request->input('fk_empleado_cedula');
        $empleado = Empleado::where('empleado_cedula',$cedula)->get();
        
        $registros = DB::table('registros')->where('registro_comentarios', 'like', 'Libre Concedido%')->where('fk_empleado_cedula',$cedula)->orderBy('registro_fecha', 'asc')->get();
  
        $pdf = PDF::loadView('pdf.libresConcedidos', compact('registros','fechainicio','fechafin','empleado'));
    	return $pdf->stream('listado.pdf');             //Ver PDF sin descargar
    }
}
