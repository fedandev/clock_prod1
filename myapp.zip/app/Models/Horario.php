<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class Horario extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['horario_nombre', 'horario_entrada', 'horario_salida', 'horario_comienzobrake', 'horario_finbrake', 'horario_tiempotarde', 'horario_salidaantes'];
    public $timestamps = false;
    
    public function HorariosRotativos()
    {
        return $this->hasMany('App\Models\HorarioRotativo', 'fk_horario_id', 'id');
    }
    
    public function Turnos()
    {
        return $this->hasMany('App\Models\Turno', 'fk_horario_id', 'id');
    }
}
