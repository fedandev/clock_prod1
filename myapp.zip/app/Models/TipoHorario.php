<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class TipoHorario extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['tipohorario_nombre', 'tipohorario_descripcion'];
    public $timestamps = false;
    
    public function TipoEmpleado()
    {
        return $this->hasOne('App\Models\TipoEmpleado','fk_tipohorario_id','id');
    }
}
