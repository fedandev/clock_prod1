<?php

namespace App\Observers;

use App\Models\Empleado;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class EmpleadoObserver
{
    public function creating(Empleado $empleado)
    {
        //
    }

    public function updating(Empleado $empleado)
    {
        //
    }
}