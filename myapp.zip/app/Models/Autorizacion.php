<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class Autorizacion extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['autorizacion_entrada', 'autorizacion_salida', 'autorizacion_autorizado'];
    public $timestamps = false;
}
