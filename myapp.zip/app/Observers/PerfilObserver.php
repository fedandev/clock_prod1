<?php

namespace App\Observers;

use App\Models\Perfil;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class PerfilObserver
{
    public function creating(Perfil $perfil)
    {
        //
    }

    public function updating(Perfil $perfil)
    {
        //
    }
}