<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class Empleado extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['empleado_cedula', 'empleado_codigo', 'empleado_nombre', 'empleado_apellido', 'empleado_correo', 'empleado_telefono', 'empleado_fingreso', 'empleado_diferenciatiempo', 'empleado_estado', 'fk_tipoempleado_id', 'fk_oficina_id'];
    public $timestamps = false;
    
    public function Oficina(){
        return $this->hasOne('App\Models\Oficina','id','fk_oficina_id');
    }
    
    public function TipoEmpleado(){
        return $this->hasOne('App\Models\TipoEmpleado','id','fk_tipoempleado_id');
    }
    
    public function Trabaja(){
        return $this->hasMany('App\Models\Trabaja','fk_empleado_id');
    }
    
    public function Registros(){
        return $this->hasMany('App\Models\Registro','empleado_cedula','fk_empleado_cedula');
    }
    
    public function Licencias(){
        return $this->hasMany('App\Models\Licencia','id','fk_empleado_id');
    }
}
