<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

class Oficina extends Model implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    protected $fillable = ['oficina_nombre', 'oficina_descripcion', 'oficina_codigo', 'oficina_estado', 'fk_sucursal_id', 'fk_dispositivo_id'];
    public $timestamps = false;
    
    public function Sucursal(){
        return $this->hasOne('App\Models\Sucursal', 'id', 'fk_sucursal_id');
    }
    
    public function Dispositivo(){
        return $this->hasOne('App\Models\Dispositivo', 'id', 'fk_dispositivo_id');
    }
}
