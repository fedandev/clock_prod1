<?php

return [
    'edit' => 'Editar',
    'index' => 'Inicio',
    'create' => 'Crear',
    'show' => 'Ver',
    'download' => 'Descargar',
    'Excel' => 'Cargar Excel',
    'search' => 'Filtrar',
    'showLoginForm','',
    'created' => 'Nuevo',
    'updated' => 'Modificado',
    'deleted' => 'Eliminado',
];