<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ asset('css/plugins/font-awesome.css') }}" />
<link rel="stylesheet" href="{{ asset('css/plugins/footable.core.css') }}" /> <!-- se usa en tablas -->
<link rel="stylesheet" href="{{ asset('css/plugins/datepicker3.css') }}"/> <!-- se usa en campos fechas -->
<link rel="stylesheet" href="{{ asset('css/plugins/select2.min.css') }}" /> <!-- se usa en select -->
<link rel="stylesheet" href="{{ asset('css/plugins/toastr.min.css') }}" /> <!-- alertas de error y mensajes -->
<link rel="stylesheet" href="{{ asset('css/plugins/style.css') }}" />
<link rel="stylesheet" href="{{ asset('css/plugins/custom-checkbox.css') }}" /> <!-- se usa en check box -->
<link rel="stylesheet" href="{{ asset('css/plugins/summernote/summernote.css') }}" /> <!-- se usa para enviar mails  -->
<link rel="stylesheet" href="{{ asset('css/plugins/summernote/summernote-bs3.css') }}" /> <!-- se usa para enviar mails  -->
<link rel="stylesheet" href="{{ asset('css/plugins/clockpicker.css') }}" /> <!-- se usa en horarios y editar registros  -->
<link rel="stylesheet" href="{{ asset('css/custom.css') }}" /> <!-- se usa para arreglos de css en varios bugs y nuevas cosas  -->