@extends('layouts.app')

@section('content')

<div class="container">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h1>Autorizacion / Show #{{ $autorizacion->id }}</h1>
            </div>

            <div class="panel-body">
                <div class="well well-sm">
                    <div class="row">
                        <div class="col-md-6">
                            <a class="btn btn-link" href="{{ route('autorizacions.index') }}"><i class="glyphicon glyphicon-backward"></i> Back</a>
                        </div>
                        <div class="col-md-6">
                             <a class="btn btn-sm btn-warning pull-right" href="{{ route('autorizacions.edit', $autorizacion->id) }}">
                                <i class="glyphicon glyphicon-edit"></i> Edit
                            </a>
                        </div>
                    </div>
                </div>

                <label>Autorizacion_entrada</label>
<p>
	{{ $autorizacion->autorizacion_entrada }}
</p> <label>Autorizacion_salida</label>
<p>
	{{ $autorizacion->autorizacion_salida }}
</p> <label>Autorizacion_autorizado</label>
<p>
	{{ $autorizacion->autorizacion_autorizado }}
</p>
            </div>
        </div>
    </div>
</div>

@endsection
