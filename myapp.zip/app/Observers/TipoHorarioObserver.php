<?php

namespace App\Observers;

use App\Models\TipoHorario;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class TipoHorarioObserver
{
    public function creating(TipoHorario $tipo_horario)
    {
        //
    }

    public function updating(TipoHorario $tipo_horario)
    {
        //
    }
}