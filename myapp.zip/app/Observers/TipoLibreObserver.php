<?php

namespace App\Observers;

use App\Models\TipoLibre;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class TipoLibreObserver
{
    public function creating(TipoLibre $tipo_libre)
    {
        //
    }

    public function updating(TipoLibre $tipo_libre)
    {
        //
    }
}