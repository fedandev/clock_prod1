<?php

namespace App\Observers;

use App\Models\Ajuste;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class AjusteObserver
{
    public function creating(Ajuste $ajuste)
    {
        //
    }

    public function updating(Ajuste $ajuste)
    {
        //
    }
}