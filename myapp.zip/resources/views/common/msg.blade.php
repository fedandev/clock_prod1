@if(session()->has('info'))
    <div class="alert alert-info alert-dismissable">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>    
         {{ session('info') }}
    </div>
@endif

@if(session()->has('warning'))
    <div class="alert alert-warning alert-dismissable">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>    
         {{ session('warning') }}
    </div>
@endif

@if(session()->has('error'))
    <div class="alert alert-error alert-dismissable">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>    
         {{ session('error') }}
    </div>
@endif

