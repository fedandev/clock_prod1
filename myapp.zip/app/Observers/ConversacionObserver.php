<?php

namespace App\Observers;

use App\Models\Conversacion;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class ConversacionObserver
{
    public function creating(Conversacion $conversacion)
    {
        //
    }

    public function updating(Conversacion $conversacion)
    {
        //
    }
}