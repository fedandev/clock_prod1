<div class="footer">
    <div class="pull-right">
        
    </div>
    <div>
        <strong>Copyright</strong> ASSE &copy; 2018
    </div>
</div>
