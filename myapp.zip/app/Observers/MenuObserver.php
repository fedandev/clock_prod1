<?php

namespace App\Observers;

use App\Models\Menu;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class MenuObserver
{
    public function creating(Menu $menu)
    {
        //
    }

    public function updating(Menu $menu)
    {
        //
    }
}