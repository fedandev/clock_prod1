@extends('layouts.app')

@section('content')
    
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>
                            <i class="fa fa-edit"></i> Reporte
                        </h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                        </div>
                    </div>
                    
                  
                    
                    <div class="ibox-content">
                        
                        <form action="{{ route('reportes.horasTrabajadasEmpleado') }}" method="POST" accept-charset="UTF-8" class="form-horizontal" id="frmReportes">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            
                            
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Fecha Inicio</label>
                                <div class="col-sm-3"><input class="form-control" type="date" name="fechainicio" id="fechainicio" required></div>
                            </div>
                            
                            
                           
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Fecha Fin</label>
                                <div class="col-sm-3"><input class="form-control" type="date" name="fechafin" id="fechafin" required></div>
                            </div>
                            
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Empleado</label>
                                <div class="col-sm-4">
                                    <select class="select2_demo_2 form-control" name="fk_empleado_cedula" id="fk_empleado_cedula">
                                        @include('layouts.empleadosXcedula');
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Reportes de empleado</label>
                                <div class="col-sm-4">
                                    <select class="select2_demo_2 form-control" name="tiporeporte" id="tiporeporte-field" required>
                                        @include('layouts.reportesXempleado');
                                    </select>
                                </div>
                            </div>
                            
                             <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <a class="btn btn-white" href="{{ route('reportes.index') }}" > Cancelar</a>
                                    <button class="btn btn-primary" type="submit">Ver</button>
                                </div>
                            </div>
                        </form>
                    </div>    
                </div>
            </div>
        </div>
    </div>

            

@endsection

@section('scripts')

    <script >
        $(document).ready(function() {
            $(".select2_demo_2").select2();
            
             $("#tiporeporte-field").change(function() {
                
                var reporte = $("#tiporeporte-field").val();
                var action = '/';
              
                if(reporte =='ht'){
                    action = '/reportes/horasTrabajadasEmpleado';
                }else if(reporte =='lt'){
                    action = '/reportes/llegadasTarde';
                }else if(reporte =='sa'){
                    action = '/reportes/salidasAntes';
                }else if(reporte =='hn'){
                    action = '/reportes/horasNocturnas';
                }else if(reporte =='he'){
                    action = '/reportes/horasExtras';
                }else if(reporte =='lf'){
                    action = '/reportes/listadoFaltas';
                }else if(reporte =='es'){
                    action = '/reportes/entradasYsalidas';
                }else if(reporte == 'lc'){
                    action = '/reportes/libresConcedidos';
                }
                
                $("#frmReportes").attr("action", action);
            });
            
            $('#date_1 .input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });
            
        });
        
       

    </script>
    
@endsection