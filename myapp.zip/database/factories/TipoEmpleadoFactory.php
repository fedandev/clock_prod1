<?php

use Faker\Generator as Faker;

$factory->define(App\Models\TipoEmpleado::class, function (Faker $faker) {
    return [
        // 'name' => $faker->name,
    ];
});
