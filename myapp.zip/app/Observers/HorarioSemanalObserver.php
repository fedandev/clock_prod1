<?php

namespace App\Observers;

use App\Models\HorarioSemanal;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class HorarioSemanalObserver
{
    public function creating(HorarioSemanal $horario_semanal)
    {
        //
    }

    public function updating(HorarioSemanal $horario_semanal)
    {
        //
    }
}