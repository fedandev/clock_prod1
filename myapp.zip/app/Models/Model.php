<?php

namespace App\Models;
use OwenIt\Auditing\Contracts\Auditable;

use Illuminate\Database\Eloquent\Model as EloquentModel;

class Model extends EloquentModel implements Auditable
{       
    use \OwenIt\Auditing\Auditable;
    public function scopeRecent($query)
    {
        return $query->orderBy('id', 'desc');
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('order', 'desc');
    }

}
