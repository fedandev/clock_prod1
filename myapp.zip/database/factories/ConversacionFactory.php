<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Conversacion::class, function (Faker $faker) {
    return [
        // 'name' => $faker->name,
    ];
});
