<?php

namespace App\Observers;

use App\Models\Feriado;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class FeriadoObserver
{
    public function creating(Feriado $feriado)
    {
        //
    }

    public function updating(Feriado $feriado)
    {
        //
    }
}