<option value="0">0</option>
<option value="1.5">1.5</option>
<option value="2">2</option>