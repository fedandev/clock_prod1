<?php

namespace App\Http\Controllers;

use App\Models\Oficina;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\OficinaRequest;

class OficinasController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', Oficina::class);
		$oficinas = Oficina::get();
		return view('oficinas.index', compact('oficinas'));
	}

    public function show(Oficina $oficina)
    {
    	$this->authorize('show', $oficina);	
        return view('oficinas.show', compact('oficina'));
    }

	public function create(Oficina $oficina)
	{
		$this->authorize('create', $oficina);
		return view('oficinas.create_and_edit', compact('oficina'));
	}

	public function store(OficinaRequest $request)
	{
		$this->authorize('store', Oficina::class);	
		$this->validate($request, [
            'oficina_nombre' => 'required|string|max:191',
            'fk_sucursal_id' => 'required|integer',
            'fk_dispositivo_id' => 'required|integer',
        ]);
        
		$oficina = Oficina::create($request->all());
		return redirect()->route('oficinas.show', $oficina->id)->with('message', 'Created successfully.');
	}

	public function edit(Oficina $oficina)
	{
        $this->authorize('edit', $oficina);
		return view('oficinas.create_and_edit', compact('oficina'));
	}

	public function update(OficinaRequest $request, Oficina $oficina)
	{
		$this->authorize('update', $oficina);
		$this->validate($request, [
            'oficina_nombre' => 'required|string|max:191',
            'fk_sucursal_id' => 'required|integer',
            'fk_dispositivo_id' => 'required|integer',
        ]);
		$oficina->update($request->all());
		return redirect()->route('oficinas.show', $oficina->id)->with('message', 'Updated successfully.');
	}

	public function destroy(Oficina $oficina)
	{
		$this->authorize('destroy', $oficina);
		$oficina->delete();
		echo '<script> localStorage.setItem("alertaverde", "Registro eliminado correctamente"); </script>';
		return redirect()->route('oficinas.index')->with('message', 'Deleted successfully.');
	}
}