<?php

namespace App\Http\Controllers;

use App\Models\Horario;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\HorarioRequest;

class HorariosController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
	{
		$this->authorize('show', Horario::class);	
		$horarios = Horario::get();
		return view('horarios.index', compact('horarios'));
	}

    public function show(Horario $horario)
    {
    	$this->authorize('show', $horario);	
        return view('horarios.show', compact('horario'));
    }

	public function create(Horario $horario)
	{
		$this->authorize('create', $horario);	
		return view('horarios.create_and_edit', compact('horario'));
	}

	public function store(HorarioRequest $request)
	{
		$this->authorize('store', Horario::class);		
		$this->validate($request, [
            'horario_nombre' => 'required|string|max:191',
            'horario_entrada' => 'required',
            'horario_salida' => 'required',
            'horario_comienzobrake' => 'required',
            'horario_finbrake' => 'required',
            'horario_tiempotarde' => 'required',
            'horario_salidaantes' => 'required',
        ]);
		$horario = Horario::create($request->all());
		return redirect()->route('horarios.show', $horario->id)->with('message', 'Created successfully.');
	}

	public function edit(Horario $horario)
	{
        $this->authorize('edit', $horario);
		return view('horarios.create_and_edit', compact('horario'));
	}

	public function update(HorarioRequest $request, Horario $horario)
	{
		$this->authorize('update', $horario);
		$this->validate($request, [
            'horario_nombre' => 'required|string|max:191',
            'horario_entrada' => 'required',
            'horario_salida' => 'required',
            'horario_comienzobrake' => 'required',
            'horario_finbrake' => 'required',
            'horario_tiempotarde' => 'required',
            'horario_salidaantes' => 'required',
        ]);
		$horario->update($request->all());

		return redirect()->route('horarios.show', $horario->id)->with('message', 'Updated successfully.');
	}

	public function destroy(Horario $horario)
	{
		$this->authorize('destroy', $horario);
		$horario->delete();
		echo '<script> localStorage.setItem("alertaverde", "Registro eliminado correctamente"); </script>';
		return redirect()->route('horarios.index')->with('message', 'Deleted successfully.');
	}
}