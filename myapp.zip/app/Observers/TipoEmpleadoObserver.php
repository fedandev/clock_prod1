<?php

namespace App\Observers;

use App\Models\TipoEmpleado;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class TipoEmpleadoObserver
{
    public function creating(TipoEmpleado $tipo_empleado)
    {
        //
    }

    public function updating(TipoEmpleado $tipo_empleado)
    {
        //
    }
}