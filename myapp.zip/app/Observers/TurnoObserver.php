<?php

namespace App\Observers;

use App\Models\Turno;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class TurnoObserver
{
    public function creating(Turno $turno)
    {
        //
    }

    public function updating(Turno $turno)
    {
        //
    }
}